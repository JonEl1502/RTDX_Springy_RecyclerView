package com.zach.salman.springylib;

/**
 * Created by salman on 21/11/16.
 */

public enum SpringAnimationType {
    TRANSLATEX,
    TRANSLATEY,
    ROTATEX,
    ROTATEY,
    SCALEXY,
    SCALEX,
    SCALEY,
    ALPHA,
    ROTATION
}
