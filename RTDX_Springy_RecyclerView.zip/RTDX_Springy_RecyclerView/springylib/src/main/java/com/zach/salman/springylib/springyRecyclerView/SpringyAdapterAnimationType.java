package com.zach.salman.springylib.springyRecyclerView;

/**
 * Created by Zach on 7/1/2017.
 */

public enum SpringyAdapterAnimationType {
    SLIDE_FROM_BOTTOM,
    SLIDE_FROM_RIGHT,
    SLIDE_FROM_LEFT,
    SCALE
}
